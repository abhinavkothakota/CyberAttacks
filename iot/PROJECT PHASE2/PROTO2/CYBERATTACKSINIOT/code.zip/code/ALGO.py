import joblib
M=joblib.load('model.pkl')
print(type(M))

